# Progetto Calabria Incanto - Todo List

## Analisi e Preparazione
- [x] Creare la struttura delle directory del progetto
- [x] Analizzare i requisiti del progetto
- [x] Creare repository GitHub
- [ ] Pianificare l'architettura dell'app e della landing page

## Design e Branding
- [ ] Progettare logo 3D con elementi simbolici della Calabria
- [ ] Selezionare palette colori rappresentativa della Calabria
- [ ] Raccogliere immagini senza copyright da Unsplash/Pexels

## Raccolta Informazioni Turistiche
- [x] Ricercare informazioni generali sulla Calabria
- [x] Identificare le principali destinazioni turistiche
- [x] Raccogliere informazioni su trasporti, cibo ed eventi
- [x] Preparare contenuti per la guida turistica

## Sviluppo Guida Turistica PDF
- [x] Creare struttura della guida in Google Docs
- [x] Scrivere introduzione alla Calabria
- [x] Descrivere le destinazioni top
- [x] Aggiungere consigli di viaggio
- [x] Creare mappa interattiva
- [x] Esportare in formato PDF/A

## Sviluppo App Web con Bubble
- [ ] Creare account Bubble gratuito
- [ ] Progettare database per l'app
- [ ] Implementare registrazione utenti (Google Login/email)
- [ ] Sviluppare funzionalità di generazione itinerari personalizzati
- [ ] Integrare API Google Maps
- [ ] Configurare raccolta dati su Google Sheets
- [ ] Creare demo interattiva

## Sviluppo Landing Page con Bubble
- [ ] Progettare layout responsive
- [ ] Implementare sezioni principali
- [ ] Aggiungere CTA per registrazione
- [ ] Integrare pulsanti di condivisione social
- [ ] Ottimizzare per SEO

## Implementazione Strategie di Crescita
- [ ] Configurare sistema di affiliazione con Refersion
- [ ] Implementare download guida PDF in cambio di registrazione
- [ ] Aggiungere funzionalità di condivisione itinerari sui social

## Pubblicazione
- [ ] Esportare file da Bubble
- [ ] Caricare file su GitHub
- [ ] Abilitare GitHub Pages
- [ ] Verificare funzionalità e link

## Documentazione
- [ ] Creare guida in Markdown su come aggiornare l'app
- [ ] Documentare processo di aggiornamento della landing page
- [ ] Spiegare come aggiornare la guida PDF

## Verifica Finale
- [ ] Controllare tutti i link
- [ ] Verificare download PDF
- [ ] Testare responsività su dispositivi mobili
- [ ] Verificare funzionalità di registrazione e generazione itinerari