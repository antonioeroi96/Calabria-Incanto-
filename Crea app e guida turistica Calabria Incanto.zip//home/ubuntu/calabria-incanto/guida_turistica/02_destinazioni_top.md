# Destinazioni Top della Calabria

## Costa Tirrenica

### Tropea
Considerata la "Perla del Tirreno", Tropea è una delle località balneari più famose della Calabria. Il suo centro storico, arroccato su una scogliera a picco sul mare, offre panorami mozzafiato sulla Costa degli Dei e sulle Isole Eolie. La spiaggia di sabbia bianca e il mare cristallino sono incorniciati dal Santuario di Santa Maria dell'Isola, simbolo della città, costruito su un promontorio roccioso.

**Da non perdere:**
- Il centro storico con i suoi palazzi nobiliari e le stradine caratteristiche
- Il Santuario di Santa Maria dell'Isola
- La spiaggia della Rotonda
- Il tramonto con vista sullo Stromboli
- La degustazione della famosa cipolla rossa di Tropea IGP

**Consigli pratici:**
- Periodo migliore per la visita: maggio-giugno e settembre per evitare la folla estiva
- Durata consigliata: 2-3 giorni
- Collegamenti: facilmente raggiungibile in treno dalla linea tirrenica

### Pizzo Calabro
A pochi chilometri da Tropea, Pizzo Calabro è un pittoresco borgo di pescatori famoso per il Castello Aragonese e per il "tartufo", un gelato semifreddo al cioccolato nato qui negli anni '50. Il centro storico è un dedalo di viuzze che conducono alla piazza principale, dove si può godere dell'atmosfera autentica della vita calabrese.

**Da non perdere:**
- Il Castello Aragonese, dove fu giustiziato Gioacchino Murat
- La Chiesa di Piedigrotta, scavata nel tufo in riva al mare
- La degustazione del tartufo di Pizzo nella storica Gelateria Enrico
- Il porto dei pescatori
- La Marina di Pizzo con le sue spiagge

**Consigli pratici:**
- Periodo migliore per la visita: primavera e inizio autunno
- Durata consigliata: 1 giorno
- Collegamenti: stazione ferroviaria sulla linea tirrenica, a 20 minuti da Lamezia Terme

### Scilla
Questo incantevole borgo marinaro è diviso in due parti: Marina Grande con la sua spiaggia e Chianalea, il quartiere dei pescatori soprannominato "la piccola Venezia del Sud" per le case costruite direttamente sul mare. Dominata dal Castello Ruffo, Scilla è legata al mito di Scilla e Cariddi narrato nell'Odissea.

**Da non perdere:**
- Il quartiere di Chianalea con le case dei pescatori
- Il Castello Ruffo con vista panoramica sullo Stretto di Messina
- La spiaggia di Marina Grande
- L'osservazione della pesca tradizionale del pesce spada
- I ristoranti di pesce fresco a Chianalea

**Consigli pratici:**
- Periodo migliore per la visita: maggio-giugno e settembre
- Durata consigliata: 1-2 giorni
- Collegamenti: stazione ferroviaria sulla linea tirrenica

## Costa Ionica

### Gerace
Considerato uno dei borghi più belli d'Italia, Gerace sorge su una rupe a 500 metri sul livello del mare, offrendo una vista spettacolare sulla costa ionica. Il centro storico medievale è un tesoro di architettura normanna, bizantina e barocca, con la Cattedrale, una delle più grandi della Calabria.

**Da non perdere:**
- La Cattedrale normanna
- La Chiesa di San Francesco
- Il Castello normanno
- Le botteghe artigiane nel centro storico
- La vista panoramica dalla Porta del Sole

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 1 giorno
- Collegamenti: raggiungibile in auto da Locri (10 km)

### Roccella Jonica
Bandiera Blu per la qualità delle sue acque, Roccella Jonica è una località balneare che combina mare cristallino, storia e cultura. Il borgo antico è dominato dal Castello Carafa, mentre la parte moderna si estende lungo la costa con un lungomare attrezzato.

**Da non perdere:**
- Il Castello Carafa
- La Chiesa Madre di San Nicola di Bari
- Le spiagge di sabbia fine
- Il Roccella Jazz Festival (agosto)
- Il porto turistico

**Consigli pratici:**
- Periodo migliore per la visita: estate per il mare, agosto per il festival jazz
- Durata consigliata: 1-2 giorni
- Collegamenti: stazione ferroviaria sulla linea ionica

### Le Castella
Parte del comune di Isola di Capo Rizzuto, Le Castella prende il nome dalla fortezza aragonese costruita su un isolotto collegato alla terraferma da una sottile lingua di terra. Questo scenario da cartolina è circondato da acque cristalline che fanno parte dell'Area Marina Protetta di Capo Rizzuto.

**Da non perdere:**
- La Fortezza Aragonese
- Le spiagge dell'Area Marina Protetta
- Le escursioni in barca
- I tramonti dalla fortezza
- La gastronomia locale a base di pesce

**Consigli pratici:**
- Periodo migliore per la visita: maggio-giugno e settembre
- Durata consigliata: 1 giorno
- Collegamenti: raggiungibile in auto da Crotone (20 km)

## Entroterra

### Parco Nazionale della Sila
L'altopiano della Sila, conosciuto come "il Gran Bosco d'Italia", offre paesaggi montani spettacolari con foreste di pini larici, laghi e una ricca fauna selvatica. Il parco è un paradiso per gli amanti della natura, con numerosi sentieri per escursioni, attività all'aria aperta e sport invernali.

**Da non perdere:**
- I laghi Arvo, Cecita e Ampollino
- Il Centro Visita Cupone con i suoi sentieri naturalistici
- Il Giganti della Sila, pini larici secolari
- Il Museo della Biodiversità di Cosenza
- Le attività invernali a Camigliatello Silano e Lorica

**Consigli pratici:**
- Periodo migliore per la visita: tutto l'anno (estate per escursioni, inverno per sci)
- Durata consigliata: 2-3 giorni
- Collegamenti: raggiungibile in auto da Cosenza o Crotone

### Parco Nazionale dell'Aspromonte
Situato all'estremità meridionale della penisola italiana, l'Aspromonte è un massiccio montuoso che offre paesaggi selvaggi e incontaminati, con profonde vallate, cascate e panorami che spaziano dallo Stretto di Messina all'Etna. Il parco è anche ricco di storia e tradizioni, con antichi borghi e santuari.

**Da non perdere:**
- Le Cascate dell'Amendolea
- Il Santuario della Madonna di Polsi
- Gambarie, principale centro turistico del parco
- I borghi abbandonati come Roghudi Vecchio
- Le escursioni al Montalto, la vetta più alta (1.956 m)

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 2 giorni
- Collegamenti: raggiungibile in auto da Reggio Calabria

### Stilo
Arroccato sulle pendici del Monte Consolino, Stilo è un borgo medievale famoso per la Cattolica, una piccola chiesa bizantina del X secolo considerata uno dei più importanti monumenti bizantini dell'Italia meridionale. Il centro storico, con le sue stradine tortuose e le case in pietra, conserva intatto il fascino medievale.

**Da non perdere:**
- La Cattolica, chiesa bizantina del X secolo
- Il Duomo
- Il Castello Normanno
- La casa natale del filosofo Tommaso Campanella
- Il Museo Civico

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 1 giorno
- Collegamenti: raggiungibile in auto dalla SS106 Ionica

## Città Principali

### Reggio Calabria
Capoluogo della regione, Reggio Calabria è una città ricca di storia e cultura, con un lungomare definito da Gabriele D'Annunzio "il chilometro più bello d'Italia". La città è famosa soprattutto per i Bronzi di Riace, due statue greche del V secolo a.C. conservate nel Museo Archeologico Nazionale.

**Da non perdere:**
- Il Museo Archeologico Nazionale con i Bronzi di Riace
- Il lungomare Falcomatà
- La Cattedrale
- Il Castello Aragonese
- Il fenomeno della Fata Morgana (miraggio ottico visibile dallo Stretto)

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 1-2 giorni
- Collegamenti: aeroporto, porto, stazione ferroviaria

### Cosenza
Conosciuta come l'"Atene della Calabria" per la sua ricca tradizione culturale, Cosenza è divisa in due parti: la città vecchia, con il suo centro storico medievale arroccato su sette colli, e la città nuova, moderna e commerciale. Il fiume Crati divide queste due anime della città.

**Da non perdere:**
- Il centro storico con la Cattedrale
- Il Castello Svevo
- Il Museo all'aperto Bilotti (MAB) con sculture di artisti contemporanei
- Il Teatro Rendano
- Il Ponte di Calatrava sul fiume Crati

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 1-2 giorni
- Collegamenti: stazione ferroviaria, autobus

### Catanzaro
Capoluogo amministrativo della Calabria, Catanzaro è conosciuta come la "città dei tre colli". Il centro storico conserva importanti monumenti, mentre la parte moderna si estende verso il mare. La città è famosa per il Ponte Morandi, una delle strutture in cemento armato più alte d'Europa.

**Da non perdere:**
- Il Duomo
- La Chiesa di San Giovanni
- Il Ponte Morandi
- Il Parco della Biodiversità Mediterranea
- Il quartiere marinaro con le sue spiagge

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 1 giorno
- Collegamenti: stazione ferroviaria, autobus

## Gemme Nascoste

### Pentedattilo
Questo borgo fantasma, il cui nome deriva dalla forma della montagna a cinque dita (penta-daktylos in greco), è uno dei luoghi più suggestivi della Calabria. Abbandonato negli anni '60, è stato parzialmente recuperato e oggi ospita botteghe artigiane e un festival di cortometraggi.

**Da non perdere:**
- Le rovine del castello e delle case abbandonate
- La vista panoramica dalla montagna
- Il Pentedattilo Film Festival (agosto)
- Le botteghe artigiane
- Le escursioni nei dintorni

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: mezza giornata
- Collegamenti: raggiungibile in auto da Reggio Calabria (25 km)

### Morano Calabro
Considerato uno dei borghi più belli d'Italia, Morano Calabro si arrampica come un presepe sulle pendici del Pollino. Il centro storico medievale, con le sue case a gradoni, offre scorci pittoreschi e testimonianze storiche di grande valore.

**Da non perdere:**
- Il Castello Normanno-Svevo
- La Collegiata di Santa Maria Maddalena
- Il Museo Naturalistico del Pollino
- La Chiesa di San Bernardino da Siena
- La Festa della Bandiera (agosto)

**Consigli pratici:**
- Periodo migliore per la visita: primavera e autunno
- Durata consigliata: 1 giorno
- Collegamenti: raggiungibile in auto dall'autostrada A2

### Chianalea di Scilla
Già menzionata come parte di Scilla, Chianalea merita una sezione a sé per la sua unicità. Questo quartiere di pescatori, con le case costruite direttamente sul mare e separate da strette viuzze che fungono da canali, crea un'atmosfera magica, soprattutto al tramonto.

**Da non perdere:**
- Le passeggiate tra le viuzze al tramonto
- I ristoranti di pesce con terrazza sul mare
- Le barche tradizionali dei pescatori
- La vista del Castello Ruffo da Chianalea
- Le fotografie delle case che sembrano emergere dall'acqua

**Consigli pratici:**
- Periodo migliore per la visita: maggio-giugno e settembre
- Durata consigliata: mezza giornata (come parte della visita a Scilla)
- Collegamenti: stazione ferroviaria di Scilla sulla linea tirrenica
