# Consigli di Viaggio

## Trasporti

### Come Arrivare in Calabria

**In Aereo**
- **Aeroporto di Lamezia Terme (SUF)**: Il principale scalo della regione, con voli nazionali e internazionali. Collegato alle principali città italiane ed europee.
- **Aeroporto di Reggio Calabria (REG)**: Collegamenti principalmente nazionali, con voli regolari da/per Roma, Milano, Torino e Bologna.
- **Aeroporto di Crotone (CRV)**: Servizi limitati, principalmente stagionali.

**In Treno**
- **Linea Tirrenica**: Collega efficacemente le città lungo la costa occidentale. I treni ad alta velocità (Frecciarossa, Frecciargento) arrivano fino a Reggio Calabria.
- **Linea Ionica**: Serve la costa orientale con collegamenti meno frequenti.
- **Informazioni e biglietti**: www.trenitalia.com

**In Auto**
- **Autostrada A2 (ex Salerno-Reggio Calabria)**: Principale arteria stradale che attraversa la regione da nord a sud.
- **SS106 Ionica**: Costeggia il litorale ionico da Reggio Calabria a Taranto.
- **SS18 Tirrena Inferiore**: Percorre la costa tirrenica.

**In Nave**
- **Porto di Villa San Giovanni**: Collegamenti frequenti con Messina (Sicilia).
- **Porto di Reggio Calabria**: Traghetti per Messina.
- **Porti turistici**: Tropea, Vibo Marina, Crotone offrono collegamenti stagionali con le isole Eolie e altre destinazioni.

### Come Muoversi in Calabria

**Trasporto Pubblico**
- **Treni regionali**: Buona copertura lungo le coste, meno efficiente verso l'interno.
- **Autobus**: Collegamenti tra città e paesi gestiti da diverse compagnie (Ferrovie della Calabria, Simet, Romano).
- **Autobus urbani**: Presenti nelle principali città (ATAM a Reggio Calabria, AMC a Catanzaro, AMACO a Cosenza).

**Auto a Noleggio**
- Disponibili presso gli aeroporti e nelle principali città.
- Opzione consigliata per esplorare liberamente la regione, soprattutto l'entroterra e le località meno servite dai mezzi pubblici.
- Principali compagnie: Hertz, Avis, Europcar, Sixt.

**Taxi**
- Disponibili nelle principali città e località turistiche.
- Tariffe generalmente più alte rispetto ad altre regioni italiane.
- Consigliabile concordare la tariffa prima della corsa.

**Consigli Pratici**
- Verificare sempre orari e frequenze in anticipo, specialmente fuori stagione.
- I servizi di trasporto pubblico sono generalmente meno frequenti la domenica e nei giorni festivi.
- Prevedere tempi di attesa tra coincidenze, specialmente quando si cambia mezzo di trasporto.
- Prenotare in anticipo durante i mesi estivi, specialmente per i collegamenti con le isole.

## Alloggi

### Tipologie di Alloggio

**Hotel**
- Presenti in tutte le principali località turistiche, con diverse categorie di prezzo.
- Maggiore concentrazione nelle zone costiere e nelle città principali.
- Prenotazione consigliata con largo anticipo per l'alta stagione (luglio-agosto).

**B&B e Agriturismi**
- Opzione ideale per chi cerca un'esperienza autentica e un contatto diretto con la cultura locale.
- Gli agriturismi offrono spesso cucina tradizionale con prodotti a km zero.
- Diffusi sia nelle zone costiere che nell'entroterra.

**Case Vacanza e Appartamenti**
- Soluzione economica e flessibile, ideale per famiglie o gruppi.
- Ampia disponibilità nelle località balneari.
- Possibilità di soggiorni settimanali o quindicinali, soprattutto in estate.

**Camping e Villaggi Turistici**
- Presenti principalmente lungo le coste.
- Offrono diverse soluzioni: piazzole per tende e camper, bungalow, mobile home.
- Spesso dotati di servizi come piscine, animazione, ristoranti.

**Alloggi Insoliti**
- Borghi-albergo: strutture ricettive diffuse in antichi borghi recuperati.
- Masserie: antiche fattorie fortificate convertite in strutture ricettive.
- Case sull'albero e glamping: esperienze di soggiorno a contatto con la natura.

### Consigli per la Prenotazione

- **Alta stagione (luglio-agosto)**: Prenotare con 3-6 mesi di anticipo.
- **Mezza stagione (maggio-giugno, settembre)**: Prenotare con 1-2 mesi di anticipo.
- **Bassa stagione (ottobre-aprile)**: Verificare l'apertura delle strutture, molte chiudono nei mesi invernali.
- **Controllare le recensioni** su piattaforme come Booking.com, Airbnb, TripAdvisor.
- **Verificare la posizione** rispetto alle attrazioni che si intende visitare e la disponibilità di parcheggio se si viaggia in auto.
- **Chiedere sconti** per soggiorni prolungati o in bassa stagione.

## Gastronomia

### Piatti da Non Perdere

**Primi Piatti**
- **Fileja con 'nduja**: Pasta fatta a mano condita con il piccante salume spalmabile.
- **Pasta con la mollica**: Condita con pangrattato tostato, acciughe e peperoncino.
- **Lagane e ceci**: Pasta larga simile a tagliatelle servita con ceci.
- **Morzello**: Zuppa piccante di interiora di vitello tipica di Catanzaro.

**Secondi Piatti**
- **Pesce spada alla ghiotta**: Tipico dello Stretto di Messina.
- **Stocco alla mammolese**: Stoccafisso preparato secondo la tradizione di Mammola.
- **Capretto alla calabrese**: Capretto cucinato con patate e aromi.
- **Frittole calabresi**: Preparazione a base di carne di maiale.

**Salumi e Formaggi**
- **'Nduja di Spilinga**: Salume spalmabile piccante.
- **Soppressata calabrese**: Salame pregiato.
- **Caciocavallo Silano DOP**: Formaggio a pasta filata.
- **Pecorino del Monte Poro**: Formaggio di pecora della zona di Vibo Valentia.

**Contorni e Antipasti**
- **Melanzane ripiene alla calabrese**: Melanzane farcite con carne e formaggio.
- **Pipi e patati**: Peperoni e patate in umido.
- **Patate 'mpacchiuse**: Patate in umido con peperoni e cipolla.
- **Pitta con sardella**: Focaccia con pasta di sardine piccante.

**Dolci**
- **Pitta 'mpigliata**: Dolce natalizio ripieno di frutta secca e miele.
- **Mostaccioli**: Biscotti duri decorati, tipici delle feste.
- **Turdilli**: Dolci fritti ricoperti di miele.
- **Cuzzupa**: Dolce pasquale a forma di ciambella con uova.

**Prodotti Tipici**
- **Cipolla Rossa di Tropea IGP**: Famosa per la sua dolcezza.
- **Bergamotto di Reggio Calabria DOP**: Agrume utilizzato principalmente per l'essenza.
- **Liquirizia di Calabria DOP**: Principalmente dalla zona di Rossano.
- **Peperoncino calabrese**: Disponibile in diverse varietà.

### Dove Mangiare

**Ristoranti Tradizionali**
- Presenti in ogni località, offrono l'autentica cucina calabrese.
- Nei piccoli centri, cercare i ristoranti frequentati dai locali.
- Prenotazione consigliata nei weekend e in alta stagione.

**Agriturismi**
- Offrono piatti preparati con prodotti a km zero.
- Esperienza gastronomica completa, spesso con menu fissi.
- Ideali per pranzi domenicali e occasioni speciali.

**Trattorie e Osterie**
- Atmosfera informale e prezzi contenuti.
- Spesso gestite a conduzione familiare.
- Menu limitati ma con piatti genuini.

**Ristoranti di Pesce**
- Eccellenti lungo le coste, con pesce freschissimo.
- Specialità locali come il pesce spada, il tonno e i frutti di mare.
- I più autentici si trovano nei piccoli porti di pescatori.

**Street Food**
- **Pitta calabrese**: Focaccia ripiena di vari ingredienti.
- **Cuddrurieddru**: Frittelle di pasta lievitata.
- **Zeppole**: Dolci fritti tipici delle feste.
- **Gelato artigianale**: Da provare il "tartufo" di Pizzo.

### Consigli per l'Esperienza Gastronomica

- **Orari dei pasti**: Pranzo 12:30-14:30, Cena 19:30-22:30.
- **Prenotazione**: Consigliata nei weekend e in alta stagione.
- **Mance**: Non obbligatorie, ma apprezzate (10% del conto).
- **Acqua**: Specificare se naturale o frizzante.
- **Vino locale**: Chiedere consigli al cameriere per abbinamenti con i piatti scelti.
- **Attenzione al piccante**: Molti piatti calabresi sono piccanti, chiedere sempre il livello di piccantezza.

## Eventi e Festival

### Eventi Stagionali

**Primavera (Marzo-Maggio)**
- **Settimana Santa**: Processioni e riti religiosi in tutta la regione.
- **Festa di San Giuseppe** (19 marzo): Celebrata con falò e degustazioni.
- **Festa della Madonna di Polsi** (aprile-maggio): Pellegrinaggio al Santuario di Polsi.
- **Primavera dei Teatri** (maggio, Castrovillari): Festival di teatro contemporaneo.

**Estate (Giugno-Agosto)**
- **Roccella Summer Festival** (Roccella Jonica): Concerti con artisti nazionali e internazionali.
- **Kaulonia Tarantella Festival** (agosto, Caulonia): Dedicato alla musica popolare calabrese.
- **Sagra della 'Nduja** (8 agosto, Spilinga): Celebrazione del famoso salume piccante.
- **Festa della Cipolla Rossa** (agosto, Tropea): Dedicata alla famosa cipolla di Tropea.
- **Palio di Ribusa** (agosto, Stilo): Rievocazione storica medievale.

**Autunno (Settembre-Novembre)**
- **Festa del Peperoncino** (settembre, Diamante): Uno degli eventi più importanti della regione.
- **Festival dei Sapori Antichi** (ottobre, Cosenza): Dedicato ai prodotti tipici calabresi.
- **Festa del Fungo** (ottobre, Camigliatello Silano): Dedicata ai funghi della Sila.
- **Festival del Cinema di Calabria** (novembre, Cosenza): Rassegna cinematografica.

**Inverno (Dicembre-Febbraio)**
- **Presepi Viventi**: Organizzati in vari borghi calabresi durante il periodo natalizio.
- **Carnevale di Castrovillari** (febbraio): Uno dei carnevali più antichi della Calabria.

### Festival Culturali

- **Pentedattilo Film Festival**: Festival internazionale di cortometraggi.
- **Trame Festival** (Lamezia Terme): Festival dei libri sulle mafie.
- **Magna Graecia Film Festival** (Catanzaro): Festival cinematografico internazionale.
- **Festival Leggere&Scrivere** (Vibo Valentia): Festival letterario con incontri con autori.

### Consigli per Partecipare agli Eventi

- **Informazioni aggiornate**: Consultare i siti ufficiali degli eventi o gli uffici turistici locali.
- **Alloggio**: Prenotare con largo anticipo per gli eventi più popolari.
- **Trasporti**: Verificare gli orari dei trasporti pubblici, che potrebbero essere potenziati durante i grandi eventi.
- **Abbigliamento**: Per gli eventi all'aperto, considerare le condizioni meteorologiche.
- **Partecipazione attiva**: Molti eventi prevedono workshop o attività interattive.

## Consigli Pratici

### Quando Andare

**Alta Stagione (Luglio-Agosto)**
- Clima caldo e soleggiato, ideale per il mare.
- Tutte le strutture turistiche sono aperte.
- Prezzi più alti e maggiore affollamento.
- Numerosi eventi e festival.

**Mezza Stagione (Maggio-Giugno, Settembre)**
- Clima mite, ideale per visite culturali e escursioni.
- Mare ancora balneabile a settembre.
- Prezzi più contenuti e meno turisti.
- Natura rigogliosa in primavera.

**Bassa Stagione (Ottobre-Aprile)**
- Clima variabile, con possibilità di piogge.
- Molte strutture turistiche chiuse nelle località balneari.
- Prezzi molto convenienti.
- Ideale per visite culturali e gastronomiche.
- Possibilità di sciare sulla Sila in inverno.

### Cosa Mettere in Valigia

**Estate**
- Abbigliamento leggero e traspirante.
- Costume da bagno, telo mare, cappello, occhiali da sole, crema solare.
- Una felpa leggera per le serate più fresche, soprattutto in montagna.
- Scarpe comode per passeggiate.
- Repellente per insetti.

**Primavera e Autunno**
- Abbigliamento a strati.
- Giacca leggera impermeabile.
- Scarpe comode per passeggiate.
- Costume da bagno (il mare può essere balneabile fino a ottobre).

**Inverno**
- Abbigliamento pesante per le zone montane.
- Giacca impermeabile.
- Sciarpa, guanti, cappello per la montagna.
- Abbigliamento più leggero per le zone costiere, dove il clima è più mite.

### Sicurezza e Salute

**Numeri di Emergenza**
- **112**: Numero unico di emergenza europeo.
- **118**: Emergenza sanitaria.
- **115**: Vigili del fuoco.
- **113**: Polizia.
- **1530**: Guardia Costiera (emergenze in mare).

**Farmacie**
- Presenti in tutti i centri abitati.
- Turni di apertura notturna e festiva indicati all'esterno di ogni farmacia.
- App utile: "Farmacia più vicina".

**Ospedali Principali**
- Reggio Calabria: Grande Ospedale Metropolitano "Bianchi-Melacrino-Morelli".
- Catanzaro: Azienda Ospedaliera "Pugliese-Ciaccio".
- Cosenza: Ospedale Civile dell'Annunziata.
- Crotone: Ospedale San Giovanni di Dio.
- Vibo Valentia: Ospedale Jazzolino.

**Consigli Sanitari**
- Portare con sé i farmaci abituali e una piccola farmacia da viaggio.
- Bere molta acqua, soprattutto in estate.
- Proteggersi dal sole con cappello, occhiali e crema solare.
- In caso di escursioni, informarsi sui percorsi e portare acqua sufficiente.

### Etiquette e Cultura Locale

**Saluti e Interazioni**
- I calabresi sono noti per la loro ospitalità e cordialità.
- Salutare con un semplice "Buongiorno" o "Buonasera" è sempre apprezzato.
- Nei piccoli centri, è comune che gli abitanti salutino anche gli sconosciuti.

**Abbigliamento**
- Casual e informale nella maggior parte delle situazioni.
- Per le chiese, evitare abiti troppo succinti (spalle coperte, pantaloni/gonne al ginocchio).
- Nei ristoranti più eleganti, evitare shorts e ciabatte.

**Orari**
- Molti negozi osservano la chiusura pomeridiana (13:00-16:30 circa).
- I pasti hanno orari precisi: pranzo 12:30-14:30, cena 19:30-22:30.
- La vita notturna inizia tardi, soprattutto in estate.

**Mance**
- Non obbligatorie, ma apprezzate nei ristoranti (10% del conto).
- Nei bar, arrotondare il conto o lasciare gli spiccioli è sufficiente.
- Per i tassisti, arrotondare la cifra.

### Connettività e Comunicazioni

**Internet e Wi-Fi**
- Copertura 4G/5G nelle principali città e località turistiche.
- Wi-Fi gratuito in molti hotel, bar, ristoranti e alcune piazze pubbliche.
- Possibilità di acquistare SIM prepagate per dati (TIM, Vodafone, WindTre, Iliad).

**Prese Elettriche**
- Standard europeo (tipo F/L), 220V.
- Portare un adattatore se si proviene da paesi con standard diversi.

**Uffici Postali**
- Presenti in tutti i centri abitati.
- Orari generalmente: lunedì-venerdì 8:20-13:35, sabato 8:20-12:35.
- Servizi disponibili: spedizioni, ritiro pacchi, servizi bancari di base.

**Uffici Turistici**
- Presenti nelle principali località turistiche.
- Offrono mappe, informazioni su attrazioni, eventi e trasporti.
- Personale spesso multilingue.

### Shopping e Souvenir

**Prodotti Tipici da Acquistare**
- **Gastronomia**: 'Nduja, peperoncino, liquirizia, bergamotto, vini locali, olio d'oliva.
- **Artigianato**: Ceramiche di Seminara, tessuti di Longobucco, oggetti in legno, strumenti musicali tradizionali.
- **Cosmetici**: Prodotti a base di bergamotto e olio d'oliva.

**Dove Fare Shopping**
- **Mercati locali**: Per prodotti freschi e artigianato.
- **Botteghe artigiane**: Nei centri storici delle città e nei borghi.
- **Centri commerciali**: Nelle principali città per shopping di marchi nazionali e internazionali.
- **Outlet**: "La Valle degli Ulivi" a Rende (CS) per abbigliamento di marca a prezzi scontati.

**Orari dei Negozi**
- Generalmente: 9:00-13:00 e 16:30-20:00.
- Chiusura settimanale: spesso il lunedì mattina.
- Centri commerciali: orario continuato, spesso anche la domenica.

**Consigli per lo Shopping**
- Contrattare i prezzi non è una pratica comune nei negozi, ma può essere accettabile nei mercati.
- Per i prodotti alimentari, verificare le norme doganali del proprio paese prima dell'acquisto.
- Conservare lo scontrino per eventuali resi o rimborsi.
