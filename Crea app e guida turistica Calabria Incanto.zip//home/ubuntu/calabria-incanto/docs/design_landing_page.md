# Progettazione Landing Page "Calabria Incanto"

## Struttura della Landing Page

### 1. Header
- **Logo**: Logo 3D di Calabria Incanto (posizionato in alto a sinistra)
- **Menu di navigazione**: Home, Funzionalità, Demo, Itinerari, Contatti
- **Call-to-Action**: Pulsante "Inizia a Esplorare" (in evidenza)
- **Login/Registrazione**: Pulsanti per accedere o registrarsi

### 2. Hero Section
- **Immagine di sfondo**: Panoramica mozzafiato della costa calabrese
- **Headline**: "Scopri la Calabria come mai prima d'ora"
- **Sottotitolo**: "Itinerari personalizzati per un'esperienza unica nella punta dello stivale"
- **Call-to-Action principale**: "Crea il tuo itinerario" (pulsante in evidenza)
- **Call-to-Action secondaria**: "Scarica la guida gratuita" (in cambio di email)

### 3. Sezione Funzionalità
- **Titolo**: "Pianifica il tuo viaggio in pochi click"
- **Caratteristiche principali** (con icone e brevi descrizioni):
  - **Itinerari Personalizzati**: "Crea percorsi su misura in base ai tuoi interessi"
  - **Ottimizzazione Tempi**: "Sfrutta Google Maps per ottimizzare i tempi di viaggio"
  - **Consigli Locali**: "Scopri gemme nascoste conosciute solo dai locali"
  - **Condivisione Social**: "Condividi i tuoi itinerari con amici e famiglia"

### 4. Demo Interattiva
- **Titolo**: "Prova Calabria Incanto in azione"
- **Video dimostrativo**: Breve tutorial sull'utilizzo dell'app
- **Demo interattiva**: Versione limitata dell'app che mostra il processo di creazione di un itinerario
- **Call-to-Action**: "Prova la demo" (pulsante che avvia la demo interattiva)

### 5. Categorie di Itinerari
- **Titolo**: "Esplora la Calabria secondo i tuoi interessi"
- **Categorie** (con immagini rappresentative):
  - **Mare**: "Scopri le spiagge più belle del Mediterraneo"
  - **Montagna**: "Avventurati nei parchi nazionali della Sila e dell'Aspromonte"
  - **Cultura**: "Immergiti nella storia millenaria e nelle tradizioni locali"
  - **Enogastronomia**: "Assapora i sapori autentici della cucina calabrese"
  - **Avventura**: "Vivi esperienze emozionanti tra mare e montagna"

### 6. Testimonianze
- **Titolo**: "Cosa dicono i nostri utenti"
- **Testimonianze**: 3-4 recensioni di utenti (da aggiungere in futuro)
- **Valutazioni**: Stelle e punteggi
- **Foto profilo**: Immagini degli utenti

### 7. Guida Turistica Gratuita
- **Titolo**: "Scarica la nostra guida completa della Calabria"
- **Immagine**: Anteprima della guida PDF
- **Descrizione**: "Oltre 50 pagine di informazioni dettagliate, consigli di viaggio e segreti locali"
- **Form**: Campo email per ricevere la guida
- **Call-to-Action**: "Scarica ora" (pulsante)
- **Privacy**: "Rispettiamo la tua privacy. Non condivideremo mai la tua email."

### 8. Come Funziona
- **Titolo**: "Come funziona Calabria Incanto"
- **Processo in 3 step** (con icone e numeri):
  1. **Inserisci le tue preferenze**: "Scegli durata, punto di partenza e interessi"
  2. **Ottieni il tuo itinerario**: "L'app genera un percorso personalizzato"
  3. **Esplora e condividi**: "Vivi la tua avventura e condividila con gli amici"
- **Call-to-Action**: "Crea il tuo itinerario ora" (pulsante)

### 9. FAQ
- **Titolo**: "Domande frequenti"
- **Accordion**: 5-6 domande e risposte comuni
  - "È completamente gratuito?"
  - "Posso modificare l'itinerario generato?"
  - "Come funziona l'ottimizzazione dei tempi?"
  - "Posso usare l'app offline?"
  - "Le informazioni sono aggiornate?"
  - "Posso contribuire con recensioni e foto?"

### 10. Footer
- **Logo**: Versione più piccola del logo
- **Navigazione**: Link alle principali sezioni del sito
- **Social Media**: Icone per Instagram, TikTok e Facebook
- **Contatti**: Email e form di contatto
- **Privacy e Termini**: Link alle pagine legali
- **Copyright**: "© 2025 Calabria Incanto. Tutti i diritti riservati."

## Design e Stile

### Palette Colori
- **Primario**: Blu mare (#1E88E5) - Rappresenta il mare cristallino della Calabria
- **Secondario**: Verde oliva (#7CB342) - Rappresenta la natura e l'entroterra
- **Accento**: Arancione calabrese (#FF8F00) - Rappresenta il sole e gli agrumi
- **Neutro chiaro**: Bianco sabbia (#F5F5F5) - Per sfondi e aree di contenuto
- **Neutro scuro**: Grigio pietra (#424242) - Per testi e dettagli

### Tipografia
- **Titoli**: Montserrat (sans-serif, bold) - Moderno e d'impatto
- **Sottotitoli**: Montserrat (sans-serif, medium) - Coerenza con i titoli
- **Corpo del testo**: Lato (sans-serif, regular) - Leggibile e pulito
- **Accenti**: Playfair Display (serif, italic) - Per citazioni e elementi decorativi

### Elementi Grafici
- **Onde stilizzate**: Rappresentano il mare, utilizzate come separatori di sezione
- **Pattern geometrici**: Ispirati ai motivi tradizionali calabresi
- **Icone lineari**: Stile minimalista con accenti di colore
- **Ombre sottili**: Per dare profondità agli elementi principali
- **Bordi arrotondati**: Per pulsanti e contenitori, stile moderno e amichevole

### Immagini
- **Fotografie panoramiche**: Per hero section e sfondi
- **Immagini di destinazioni**: Per le categorie di itinerari
- **Foto di esperienze**: Persone che godono delle attrazioni calabresi
- **Icone tematiche**: Per rappresentare le funzionalità e i processi

## Responsive Design

### Desktop (1200px+)
- Layout completo con tutte le sezioni
- Menu di navigazione orizzontale
- Demo interattiva in dimensioni ottimali
- Griglia a 3-4 colonne per le categorie di itinerari

### Tablet (768px - 1199px)
- Layout adattato con le stesse sezioni
- Menu di navigazione orizzontale o hamburger
- Demo interattiva ridimensionata
- Griglia a 2 colonne per le categorie di itinerari

### Mobile (320px - 767px)
- Layout semplificato e verticale
- Menu hamburger per la navigazione
- Demo interattiva ottimizzata per touch
- Griglia a 1 colonna per le categorie di itinerari
- CTA più grandi e facili da toccare

## Animazioni e Interazioni

### Animazioni di Caricamento
- Fade-in progressivo degli elementi al caricamento della pagina
- Parallasse sottile per la hero section
- Animazione del logo al passaggio del mouse

### Interazioni
- Hover effects sui pulsanti e link
- Transizioni fluide tra le sezioni
- Animazioni al click per la FAQ (accordion)
- Feedback visivi per le azioni dell'utente

### Microinterazioni
- Pulsanti che cambiano colore al passaggio del mouse
- Icone che si animano leggermente
- Feedback di successo dopo l'invio del form
- Indicatori di caricamento per le azioni

## Ottimizzazione SEO

### Meta Tag
- **Title**: "Calabria Incanto - Itinerari Turistici Personalizzati in Calabria"
- **Description**: "Crea itinerari turistici personalizzati in Calabria. Scopri le spiagge, i borghi, la cultura e la gastronomia calabrese con percorsi su misura."
- **Keywords**: calabria, turismo, itinerari, vacanze, mare, montagna, cultura, enogastronomia

### Struttura URL
- URL principale: calabriaincanto.it
- URL sezioni: calabriaincanto.it/funzionalita, calabriaincanto.it/demo, ecc.

### Contenuti Ottimizzati
- Heading tags gerarchici (H1, H2, H3)
- Alt text per tutte le immagini
- Contenuti testuali ricchi di keyword naturali
- Link interni tra le sezioni correlate

### Dati Strutturati
- Schema.org markup per:
  - Organizzazione
  - Prodotto (app)
  - FAQ
  - Recensioni

## Strategie di Conversione

### Call-to-Action Principali
- "Crea il tuo itinerario" (pulsante primario)
- "Scarica la guida gratuita" (pulsante secondario)
- "Prova la demo" (pulsante terziario)

### Lead Magnet
- Guida turistica PDF in cambio dell'email
- Anteprima di itinerari personalizzati

### Social Proof
- Testimonianze di utenti
- Contatore di itinerari creati
- Badge di riconoscimento (es. "Scelto da X turisti")

### FOMO (Fear of Missing Out)
- "Scopri le gemme nascoste della Calabria"
- "Accesso anticipato alle nuove funzionalità"
- "Offerte esclusive per i primi iscritti"

## Integrazioni Tecniche

### Google Analytics
- Tracciamento delle conversioni
- Analisi del comportamento degli utenti
- Monitoraggio delle performance della pagina

### Google Tag Manager
- Gestione centralizzata dei tag
- A/B testing delle CTA
- Remarketing

### Social Media
- Pulsanti di condivisione
- Feed Instagram integrato
- Widget per recensioni Facebook

### Newsletter
- Integrazione con servizio di email marketing
- Automazioni per l'invio della guida PDF
- Segmentazione degli utenti

## Piano di Implementazione

### Fase 1: Wireframing e Prototipazione
- Creazione wireframe per desktop, tablet e mobile
- Prototipo interattivo delle principali funzionalità
- Test di usabilità iniziale

### Fase 2: Design UI/UX
- Applicazione della palette colori e tipografia
- Creazione degli elementi grafici
- Design completo di tutte le sezioni

### Fase 3: Sviluppo Frontend
- Implementazione HTML/CSS responsive
- Sviluppo delle animazioni e interazioni
- Ottimizzazione per diversi dispositivi

### Fase 4: Integrazione Backend
- Collegamento con l'app Bubble.io
- Implementazione del form per la guida PDF
- Setup delle integrazioni tecniche

### Fase 5: Test e Ottimizzazione
- Test di usabilità
- Ottimizzazione delle performance
- A/B testing delle CTA

### Fase 6: Lancio
- Pubblicazione su GitHub Pages
- Monitoraggio iniziale
- Raccolta feedback
