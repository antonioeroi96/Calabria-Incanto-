# Istruzioni per la Pubblicazione su GitHub Pages

Per pubblicare la landing page di Calabria Incanto su GitHub Pages, segui questi passaggi:

1. Assicurati di avere un account GitHub e di aver creato un repository per il progetto.

2. Clona il repository sul tuo computer locale:
```bash
git clone https://github.com/tuousername/calabria-incanto.git
cd calabria-incanto
```

3. Copia tutti i file della landing page nella directory principale del repository:
   - index.html
   - La directory css/ con tutti i file CSS
   - La directory js/ con tutti i file JavaScript
   - La directory images/ con tutte le immagini
   - La directory guida_turistica/ con il PDF della guida

4. Aggiungi i file al repository Git:
```bash
git add .
```

5. Esegui un commit dei file:
```bash
git commit -m "Aggiunti file per la landing page di Calabria Incanto"
```

6. Pusha i file sul repository remoto:
```bash
git push origin main
```

7. Vai alle impostazioni del repository su GitHub:
   - Naviga su GitHub e accedi al tuo repository
   - Clicca sulla scheda "Settings"
   - Scorri fino alla sezione "GitHub Pages"

8. Nella sezione GitHub Pages:
   - Seleziona "main" come Source branch
   - Seleziona "/" (root) come directory
   - Clicca su "Save"

9. Attendi qualche minuto che GitHub Pages pubblichi il tuo sito.

10. Il tuo sito sarà disponibile all'URL: https://tuousername.github.io/calabria-incanto/

## Sostituzione dei Placeholder con Immagini Reali

Per sostituire i placeholder con immagini reali:

1. Raccogli immagini senza copyright da fonti come Pixabay, Unsplash o Pexels.

2. Ottimizza le immagini per il web:
   - Ridimensiona le immagini alle dimensioni appropriate
   - Comprimi le immagini per ridurre le dimensioni dei file
   - Salva le immagini in formato JPEG per le fotografie e PNG per le immagini con trasparenza

3. Salva le immagini nella directory `images/` con nomi descrittivi.

4. Modifica il file `index.html` sostituendo i placeholder con le immagini reali:
   - Sostituisci i div con classe "placeholder" con tag img
   - Aggiungi l'attributo src con il percorso dell'immagine
   - Aggiungi l'attributo alt con una descrizione dell'immagine

Esempio:
```html
<!-- Da sostituire: -->
<div class="placeholder placeholder-hero">
    <div class="hero-content">
        <h1>Scopri la Calabria come mai prima d'ora</h1>
        <!-- ... -->
    </div>
</div>

<!-- Con: -->
<div class="hero" style="background-image: url('images/tropea-panorama.jpg');">
    <div class="hero-content">
        <h1>Scopri la Calabria come mai prima d'ora</h1>
        <!-- ... -->
    </div>
</div>
```

5. Rimuovi il riferimento al file CSS dei placeholder:
```html
<!-- Rimuovi questa riga: -->
<link rel="stylesheet" href="css/placeholders.css">
```

6. Aggiorna il repository con le modifiche:
```bash
git add .
git commit -m "Sostituite immagini placeholder con immagini reali"
git push origin main
```

7. GitHub Pages aggiornerà automaticamente il sito con le nuove immagini.

## Aggiornamento della Guida Turistica PDF

Per aggiornare la guida turistica PDF:

1. Modifica il file PDF originale.

2. Salva il nuovo PDF nella directory `guida_turistica/`.

3. Aggiorna il repository:
```bash
git add guida_turistica/Calabria_Incanto_Guida_Turistica.pdf
git commit -m "Aggiornata la guida turistica PDF"
git push origin main
```

4. Aggiorna il link nel file `index.html` se necessario.

## Aggiornamento delle Funzionalità JavaScript

Per aggiornare le funzionalità JavaScript:

1. Modifica il file `js/main.js`.

2. Aggiorna il repository:
```bash
git add js/main.js
git commit -m "Aggiornate le funzionalità JavaScript"
git push origin main
```

## Monitoraggio e Analisi

Per monitorare le visite e l'utilizzo del sito:

1. Crea un account Google Analytics.

2. Aggiungi il codice di tracciamento nel tag `<head>` del file `index.html`:
```html
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

3. Sostituisci `GA_MEASUREMENT_ID` con il tuo ID di misurazione Google Analytics.

4. Aggiorna il repository:
```bash
git add index.html
git commit -m "Aggiunto codice di tracciamento Google Analytics"
git push origin main
```

## Risoluzione dei Problemi Comuni

1. **Il sito non viene pubblicato**: Verifica che il branch e la directory selezionati nelle impostazioni di GitHub Pages siano corretti.

2. **Le immagini non vengono visualizzate**: Controlla i percorsi delle immagini e assicurati che siano relativi alla directory principale.

3. **Il CSS non viene applicato**: Verifica che i percorsi dei file CSS siano corretti e che i file siano stati caricati correttamente.

4. **JavaScript non funziona**: Apri la console del browser per verificare eventuali errori JavaScript e correggi il codice di conseguenza.

5. **Problemi di responsive design**: Testa il sito su diversi dispositivi e browser per assicurarti che sia visualizzato correttamente.
