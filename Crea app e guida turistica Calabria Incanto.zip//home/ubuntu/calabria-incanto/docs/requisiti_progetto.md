# Analisi dei Requisiti del Progetto "Calabria Incanto"

## Obiettivo Generale
Creare un'app web con landing page chiamata "Calabria Incanto" che generi itinerari turistici personalizzati in Calabria, completa di logo 3D e guida turistica in PDF.

## Vincoli Fondamentali
- **Costo Zero**: Utilizzare esclusivamente strumenti e servizi gratuiti
- **Completamento in un'unica esecuzione**: Il progetto deve essere completato senza necessità di correzioni successive
- **Scalabilità**: Il progetto deve essere facilmente espandibile in futuro
- **Documentazione chiara**: Fornire una guida in formato Markdown su come aggiornare tutti i componenti

## 1. Sviluppo dell'App Web e Landing Page

### Tecnologie e Piattaforme
- **Bubble**: Piattaforma no-code per lo sviluppo dell'app web e della landing page (versione gratuita)
- **GitHub Pages**: Per l'hosting gratuito del sito
- **Google Sheets**: Per la raccolta dei dati degli utenti
- **Google Maps API**: Per l'ottimizzazione dei tempi di viaggio

### Funzionalità dell'App
- Registrazione utenti con Google Login o email indipendente
- Generazione di itinerari personalizzati in base a:
  - Numero di giorni disponibili
  - Punto di partenza
  - Tipologia preferita (mare, montagna, cultura, enogastronomia, avventura)
- Ottimizzazione dei tempi di viaggio tramite Google Maps API
- Demo interattiva pre-registrazione
- Condivisione degli itinerari sui social media

### Requisiti della Landing Page
- Design moderno, unico e responsive
- Utilizzo dei colori rappresentativi della Calabria
- CTA forte per incentivare la registrazione
- Messaggio chiaro sulla gratuità dello strumento
- Testo coinvolgente sui benefici dell'app
- Ottimizzazione SEO
- Pulsanti di condivisione per Instagram, TikTok e Facebook

## 2. Design e Branding

### Logo 3D
- Creazione con strumento gratuito
- Inclusione di elementi simbolici della Calabria:
  - Mare
  - Sole
  - Bronzi di Riace
  - Bergamotto
- Formato richiesto: SVG

### Immagini
- Utilizzo esclusivo di immagini senza copyright da Unsplash o Pexels
- Immagini evocative della Calabria

## 3. Guida Turistica PDF

### Strumento di Creazione
- Google Docs (gratuito)

### Struttura della Guida
- Introduzione alla Calabria
- Destinazioni top con descrizioni dettagliate
- Consigli di viaggio (trasporti, cibo, eventi)
- Mappa interattiva con link cliccabili

### Formato di Esportazione
- PDF/A per garantire alta qualità e compatibilità

## 4. Strategie di Crescita e Monetizzazione

### Sistema di Affiliazione
- Refersion (versione gratuita) per tracciare le iscrizioni generate dagli influencer locali

### Strategie di Acquisizione Utenti
- Offerta della guida turistica PDF gratuita in cambio della registrazione via email
- Condivisione degli itinerari personalizzati sui social con link diretto

## 5. Output Finale Richiesto
- Link alla landing page pubblicata su GitHub Pages
- Link all'app web funzionante su Bubble
- File del logo 3D in formato SVG
- PDF della guida turistica pronto per il download
- Guida Markdown su come aggiornare il progetto

## 6. Controllo degli Errori
- Verifica di tutti i link
- Controllo del download del PDF
- Test di accessibilità e responsività su dispositivi mobili
