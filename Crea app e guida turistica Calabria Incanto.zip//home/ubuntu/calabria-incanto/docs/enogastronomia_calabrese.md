# Enogastronomia Calabrese

## Panoramica

La cucina calabrese è una cucina ricca e variegata, di origine contadina, fortemente influenzata dalla storia e dalle tradizioni locali. È caratterizzata dall'uso abbondante di peperoncino, che è diventato un simbolo della regione, e da una grande varietà di prodotti tipici che riflettono la biodiversità del territorio.

## Piatti Tipici

### Primi Piatti

- **Pasta c'anciova e ca muddica atturrata**: Pasta con acciughe e mollica di pane tostata
- **Fileja**: Pasta fatta a mano arrotolata su un ferro da calza, servita con vari condimenti
- **Lagane e ceci**: Pasta larga simile a tagliatelle servita con ceci
- **Maccaruni i casa**: Pasta fatta in casa con sugo di carne
- **Gnocchi alla calabrese**: Con mandorle e peperoncino
- **Parmigiana**: Versione calabrese con melanzane, mozzarella, pomodoro e prosciutto
- **Morzello**: Zuppa piccante di interiora di vitello tipica di Catanzaro

### Secondi Piatti

- **Ragù alla calabrese**: Sugo di carne a cottura lenta
- **Pesce stocco alla mammolese**: Stoccafisso preparato secondo la tradizione di Mammola
- **Frittole calabresi**: Preparazione a base di carne di maiale
- **Capretto alla calabrese**: Capretto cucinato con patate e aromi
- **Peperonata**: Piatto a base di peperoni, cipolle e pomodori
- **Pipi e patati**: Peperoni e patate in umido
- **Baccalà alla cosentina**: Baccalà con patate, olive e peperoncino

### Salumi e Formaggi

- **'Nduja**: Salume spalmabile piccante tipico di Spilinga
- **Spianata calabra**: Salame schiacciato e piccante
- **Capocollo di Calabria DOP**: Salume preparato con carne di suino
- **Pancetta di Calabria DOP**: Pancetta aromatizzata
- **Salsiccia di Calabria DOP**: Salsiccia piccante
- **Soppressata di Calabria DOP**: Salame pregiato
- **Caciocavallo Silano DOP**: Formaggio a pasta filata
- **Pecorino Crotonese DOP**: Formaggio di pecora
- **Pecorino del Monte Poro**: Formaggio di pecora della zona di Vibo Valentia

### Contorni e Antipasti

- **Melanzane ripiene alla calabrese**: Melanzane farcite con carne e formaggio
- **Vruacculi i rapa e sazizza**: Broccoli di rapa fritti con salsiccia (tipico cosentino)
- **Maccu di fave**: Purea di fave secche servita con olio d'oliva
- **Patate 'mpacchiuse**: Patate in umido con peperoni e cipolla
- **Pitta con sardella**: Focaccia con pasta di sardine piccante

### Dolci

- **Pitta 'mpigliata**: Dolce natalizio ripieno di frutta secca e miele
- **Mostaccioli**: Biscotti duri decorati, tipici delle feste
- **Turdilli**: Dolci fritti ricoperti di miele
- **Cuzzupa**: Dolce pasquale a forma di ciambella con uova
- **Pignolata**: Palline di pasta fritta ricoperte di miele o cioccolato
- **Susumelle**: Biscotti al miele con spezie

## Prodotti Tipici

### Ortaggi e Frutta

- **Cipolla Rossa di Tropea IGP**: Famosa per la sua dolcezza
- **Bergamotto di Reggio Calabria DOP**: Agrume utilizzato principalmente per l'essenza
- **Clementine di Calabria IGP**: Agrumi dolci e succosi
- **Patata della Sila IGP**: Coltivata sull'altopiano silano
- **Pomodoro di Belmonte**: Varietà locale pregiata

### Condimenti e Spezie

- **Peperoncino calabrese**: Disponibile in diverse varietà, simbolo della cucina piccante regionale
- **Olio extravergine d'oliva**: Prodotto in diverse varietà locali
- **Liquirizia di Calabria DOP**: Principalmente dalla zona di Rossano
- **Origano calabrese**: Aromatico e intenso

### Vini

- **Cirò DOC**: Uno dei vini più antichi d'Italia, disponibile in versione rossa, bianca e rosata
- **Greco di Bianco DOC**: Vino dolce da dessert
- **Savuto DOC**: Vino rosso corposo
- **Lamezia DOC**: Vino rosso, bianco e rosato
- **Melissa DOC**: Vino rosso e bianco

## Eventi Gastronomici

- **Festa del Peperoncino** (Diamante, settembre): Celebrazione del peperoncino calabrese
- **Sagra della 'Nduja** (Spilinga, agosto): Dedicata al famoso salume piccante
- **Festa della Cipolla Rossa** (Tropea, agosto): Celebra la famosa cipolla di Tropea
- **Festival dei Sapori Antichi** (Cosenza, ottobre): Dedicato ai prodotti tipici calabresi
- **Sagra del Bergamotto** (Reggio Calabria, dicembre): Celebra l'agrume simbolo della zona
- **Festa del Vino Cirò** (Cirò Marina, agosto): Dedicata al famoso vino calabrese
- **Sagra della Pitta 'Mpigliata** (San Giovanni in Fiore, dicembre): Celebra il dolce natalizio

## Tradizioni Culinarie

- **Cucina delle festività**: Molti piatti sono legati alle ricorrenze religiose (13 portate a Natale e all'Epifania)
- **Cucina di Carnevale**: Tradizione di mangiare maccheroni, polpette e carne di maiale
- **Conserve fatte in casa**: Tradizione di preparare conserve di pomodoro, melanzane e peperoni
- **Pane fatto in casa**: Diverse varietà di pane tradizionale come la pitta calabrese

## Esperienze Gastronomiche per Turisti

- **Tour enogastronomici**: Percorsi organizzati tra cantine, frantoi e aziende agricole
- **Corsi di cucina calabrese**: Disponibili in diverse località turistiche
- **Degustazioni di vini e prodotti tipici**: Offerte da molte aziende agricole
- **Ristoranti tradizionali**: Dove assaporare l'autentica cucina calabrese
- **Agriturismi**: Offrono piatti preparati con prodotti a km zero
