# Architettura dell'App Web "Calabria Incanto"

## Panoramica

L'app web "Calabria Incanto" è progettata per generare itinerari turistici personalizzati in Calabria, offrendo agli utenti un'esperienza interattiva per pianificare il loro viaggio in base a preferenze specifiche. L'app sarà sviluppata utilizzando Bubble.io, una piattaforma no-code che permette di creare applicazioni web complesse senza scrivere codice.

## Struttura del Database

### Tabella Utenti
- **ID**: Identificatore unico dell'utente
- **Email**: Email dell'utente (utilizzata per login)
- **Nome**: Nome dell'utente
- **Cognome**: Cognome dell'utente
- **Data di registrazione**: Data di creazione dell'account
- **Preferenze**: Preferenze salvate dell'utente (tipo JSON)
- **Itinerari salvati**: Relazione con la tabella Itinerari

### Tabella Destinazioni
- **ID**: Identificatore unico della destinazione
- **Nome**: Nome della destinazione
- **Descrizione**: Descrizione dettagliata
- **Categoria**: Tipo di destinazione (mare, montagna, cultura, enogastronomia, avventura)
- **Coordinate**: Latitudine e longitudine
- **Immagine URL**: Link all'immagine della destinazione
- **Tempo di visita consigliato**: In ore
- **Stagionalità**: Periodo migliore per la visita
- **Costo indicativo**: Fascia di prezzo
- **Popolarità**: Punteggio di popolarità

### Tabella Itinerari
- **ID**: Identificatore unico dell'itinerario
- **Utente**: Relazione con la tabella Utenti
- **Nome**: Nome dell'itinerario
- **Data creazione**: Data di creazione dell'itinerario
- **Punto di partenza**: Località di partenza
- **Durata**: Numero di giorni
- **Tipologia preferita**: Categoria principale (mare, montagna, cultura, enogastronomia, avventura)
- **Destinazioni**: Relazione con la tabella Destinazioni (lista ordinata)
- **Percorso ottimizzato**: Percorso calcolato con Google Maps
- **Pubblico**: Booleano che indica se l'itinerario è condivisibile

### Tabella Recensioni
- **ID**: Identificatore unico della recensione
- **Utente**: Relazione con la tabella Utenti
- **Destinazione**: Relazione con la tabella Destinazioni
- **Valutazione**: Punteggio da 1 a 5
- **Commento**: Testo della recensione
- **Data**: Data della recensione
- **Foto**: URL delle foto caricate (opzionale)

## Flussi di Lavoro Principali

### Registrazione e Login
1. **Registrazione con email**:
   - L'utente inserisce email e password
   - Il sistema invia email di conferma
   - L'utente conferma l'email e completa il profilo

2. **Login con Google**:
   - L'utente clicca su "Accedi con Google"
   - Autorizzazione tramite OAuth
   - Reindirizzamento al profilo utente

### Generazione Itinerario Personalizzato
1. **Input parametri**:
   - Numero di giorni disponibili
   - Punto di partenza
   - Tipologia preferita (mare, montagna, cultura, enogastronomia, avventura)
   - Preferenze aggiuntive (opzionali)

2. **Elaborazione**:
   - Selezione delle destinazioni in base ai parametri
   - Calcolo delle distanze e tempi di percorrenza con Google Maps API
   - Ottimizzazione del percorso
   - Generazione dell'itinerario giorno per giorno

3. **Output**:
   - Visualizzazione dell'itinerario su mappa
   - Elenco dettagliato delle destinazioni con tempi e distanze
   - Opzione per modificare manualmente l'itinerario
   - Possibilità di salvare e condividere

### Salvataggio e Condivisione
1. **Salvataggio itinerario**:
   - L'utente salva l'itinerario nel proprio profilo
   - Possibilità di aggiungere note personali

2. **Condivisione sui social**:
   - Generazione di link condivisibile
   - Opzioni per condividere su Instagram, TikTok e Facebook
   - Anteprima dell'itinerario per condivisione

### Demo Interattiva
1. **Funzionamento pre-registrazione**:
   - Itinerario di esempio pre-generato
   - Interazione limitata con la mappa
   - Call-to-action per registrazione completa

## Integrazione API

### Google Maps API
- **Geocoding**: Conversione di indirizzi in coordinate
- **Distance Matrix**: Calcolo di distanze e tempi di percorrenza
- **Directions**: Ottimizzazione dei percorsi
- **Maps JavaScript API**: Visualizzazione delle mappe interattive

### Google Login API
- Autenticazione OAuth per login con Google

### Google Sheets API
- Raccolta e archiviazione dei dati degli utenti
- Esportazione di statistiche e analisi

### Refersion API (versione gratuita)
- Tracciamento delle iscrizioni generate dagli influencer locali
- Gestione del programma di affiliazione

## Interfaccia Utente

### Landing Page
- **Hero Section**: Immagine panoramica della Calabria con call-to-action
- **Sezione Funzionalità**: Spiegazione delle principali funzionalità dell'app
- **Demo Interattiva**: Anteprima del funzionamento dell'app
- **Testimonianze**: Feedback di utenti (da aggiungere in futuro)
- **FAQ**: Domande frequenti
- **Footer**: Link utili, social media, contatti

### Dashboard Utente
- **Riepilogo**: Itinerari salvati e recenti
- **Profilo**: Gestione informazioni personali
- **Preferenze**: Impostazioni delle preferenze di viaggio
- **Notifiche**: Aggiornamenti e novità

### Generatore di Itinerari
- **Form di input**: Campi per inserire i parametri
- **Mappa interattiva**: Visualizzazione dell'itinerario
- **Timeline**: Visualizzazione giorno per giorno
- **Dettagli destinazioni**: Informazioni sulle località incluse
- **Opzioni di modifica**: Strumenti per personalizzare l'itinerario

### Pagina Destinazione
- **Galleria immagini**: Foto della destinazione
- **Descrizione**: Informazioni dettagliate
- **Mappa**: Posizione geografica
- **Recensioni**: Feedback degli utenti
- **Itinerari correlati**: Altri itinerari che includono la destinazione

## Responsive Design

L'app sarà completamente responsive, ottimizzata per:
- **Desktop**: Layout completo con tutte le funzionalità
- **Tablet**: Layout adattato con focus sulle funzionalità principali
- **Mobile**: Versione semplificata con focus sulla generazione di itinerari e visualizzazione

## Strategie SEO

- **Meta tag ottimizzati**: Titoli e descrizioni per ogni pagina
- **URL semantici**: Struttura URL chiara e descrittiva
- **Contenuti ricchi**: Descrizioni dettagliate delle destinazioni
- **Schema markup**: Implementazione di dati strutturati
- **Ottimizzazione immagini**: Alt text e dimensioni ottimizzate

## Strategie di Crescita

### Acquisizione Utenti
- **Guida PDF gratuita**: Offerta in cambio della registrazione
- **Demo interattiva**: Esperienza limitata senza registrazione
- **Condivisione social**: Funzionalità di condivisione degli itinerari

### Retention
- **Email marketing**: Aggiornamenti su nuove destinazioni e funzionalità
- **Gamification**: Badge e riconoscimenti per gli utenti attivi
- **Contenuti esclusivi**: Suggerimenti di viaggio personalizzati

### Monetizzazione Futura
- **Partnership con attività locali**: Promozioni e offerte speciali
- **Itinerari premium**: Funzionalità avanzate per utenti premium
- **Affiliazione**: Commissioni su prenotazioni hotel e attività

## Requisiti Tecnici

### Hosting
- **GitHub Pages**: Per la landing page statica
- **Bubble.io**: Per l'app web dinamica

### Performance
- **Tempo di caricamento**: Ottimizzazione per caricamento rapido
- **Caching**: Implementazione di strategie di caching
- **Lazy loading**: Caricamento progressivo delle immagini

### Sicurezza
- **HTTPS**: Connessione sicura
- **Autenticazione**: Gestione sicura delle credenziali
- **Protezione dati**: Conformità GDPR

## Piano di Implementazione

### Fase 1: Setup e Struttura Base
- Creazione dell'account Bubble.io
- Definizione del database
- Implementazione del sistema di autenticazione

### Fase 2: Funzionalità Core
- Sviluppo del generatore di itinerari
- Integrazione con Google Maps API
- Implementazione della demo interattiva

### Fase 3: UI/UX e Responsive
- Design della landing page
- Design dell'interfaccia utente dell'app
- Ottimizzazione responsive

### Fase 4: Integrazione e Test
- Collegamento con Google Sheets
- Implementazione della condivisione social
- Test completi di tutte le funzionalità

### Fase 5: Lancio e Monitoraggio
- Pubblicazione su GitHub Pages
- Monitoraggio delle performance
- Raccolta feedback iniziali
