document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            mainNav.style.display = mainNav.style.display === 'flex' ? 'none' : 'flex';
            this.classList.toggle('active');
        });
    }
    
    // FAQ accordion
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            item.classList.toggle('active');
            
            // Close other open FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
        });
    });
    
    // Demo form functionality
    const generateDemoBtn = document.getElementById('generate-demo');
    const demoResult = document.getElementById('demo-result');
    
    if (generateDemoBtn) {
        generateDemoBtn.addEventListener('click', function() {
            const startPoint = document.getElementById('start-point').value;
            const days = document.getElementById('days').value;
            const interests = Array.from(document.querySelectorAll('input[name="interests"]:checked')).map(el => el.value);
            
            if (!startPoint || !days || interests.length === 0) {
                alert('Per favore, compila tutti i campi e seleziona almeno un interesse.');
                return;
            }
            
            // Generate demo itinerary
            generateDemoItinerary(startPoint, days, interests);
        });
    }
    
    // Guide download form
    const guideForm = document.getElementById('guide-form');
    
    if (guideForm) {
        guideForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('guide-email').value;
            
            if (!email) {
                alert('Per favore, inserisci la tua email.');
                return;
            }
            
            // Simulate sending the guide
            alert('Grazie! La guida turistica è stata inviata alla tua email: ' + email);
            
            // In a real implementation, this would send the request to a server
            // and then provide the download link or send the PDF via email
            
            // For demo purposes, we'll provide a direct download link
            const pdfLink = document.createElement('a');
            pdfLink.href = 'guida_turistica/Calabria_Incanto_Guida_Turistica.pdf';
            pdfLink.download = 'Calabria_Incanto_Guida_Turistica.pdf';
            pdfLink.click();
            
            // Reset the form
            guideForm.reset();
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80, // Adjust for header height
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Video placeholder click
    const videoPlaceholder = document.querySelector('.video-placeholder');
    
    if (videoPlaceholder) {
        videoPlaceholder.addEventListener('click', function() {
            // In a real implementation, this would play a video
            alert('In una versione completa, qui verrebbe riprodotto un video dimostrativo dell\'app.');
        });
    }
    
    // Newsletter form
    const newsletterForm = document.querySelector('.newsletter-form');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            if (!email) {
                alert('Per favore, inserisci la tua email.');
                return;
            }
            
            alert('Grazie per esserti iscritto alla nostra newsletter!');
            this.reset();
        });
    }
});

// Function to generate a demo itinerary
function generateDemoItinerary(startPoint, days, interests) {
    const demoResult = document.getElementById('demo-result');
    
    // Sample destinations data (in a real app, this would come from a database)
    const destinations = {
        'mare': [
            { name: 'Tropea', description: 'Famosa per le sue spiagge bianche e il centro storico', image: 'images/tropea.jpg' },
            { name: 'Capo Vaticano', description: 'Baie e calette nascoste con acque cristalline', image: 'images/capo-vaticano.jpg' },
            { name: 'Scilla', description: 'Pittoresco borgo di pescatori con la spiaggia di Chianalea', image: 'images/scilla.jpg' },
            { name: 'Praia a Mare', description: 'Nota per l\'Isola di Dino e le sue grotte marine', image: 'images/praia-a-mare.jpg' }
        ],
        'montagna': [
            { name: 'Parco Nazionale della Sila', description: 'Foreste, laghi e sentieri escursionistici', image: 'images/sila.jpg' },
            { name: 'Parco Nazionale dell\'Aspromonte', description: 'Montagne, cascate e panorami mozzafiato', image: 'images/aspromonte.jpg' },
            { name: 'Parco Nazionale del Pollino', description: 'Il parco nazionale più grande d\'Italia', image: 'images/pollino.jpg' }
        ],
        'cultura': [
            { name: 'Reggio Calabria', description: 'Museo Archeologico Nazionale con i Bronzi di Riace', image: 'images/reggio-calabria.jpg' },
            { name: 'Gerace', description: 'Borgo medievale con la Cattedrale', image: 'images/gerace.jpg' },
            { name: 'Stilo', description: 'La Cattolica bizantina e il centro storico', image: 'images/stilo.jpg' },
            { name: 'Cosenza', description: 'Centro storico e Castello Svevo', image: 'images/cosenza.jpg' }
        ],
        'enogastronomia': [
            { name: 'Cirò', description: 'Famosa per i suoi vini DOC', image: 'images/ciro.jpg' },
            { name: 'Spilinga', description: 'Patria della \'nduja calabrese', image: 'images/spilinga.jpg' },
            { name: 'Pizzo', description: 'Famosa per il tartufo gelato', image: 'images/pizzo.jpg' },
            { name: 'Diamante', description: 'Capitale del peperoncino calabrese', image: 'images/diamante.jpg' }
        ],
        'avventura': [
            { name: 'Gole del Raganello', description: 'Trekking e canyoning in uno scenario spettacolare', image: 'images/raganello.jpg' },
            { name: 'Isola di Dino', description: 'Snorkeling e kayak nelle grotte marine', image: 'images/isola-dino.jpg' },
            { name: 'Monte Cocuzzo', description: 'Parapendio e panorami sulla costa tirrenica', image: 'images/monte-cocuzzo.jpg' }
        ]
    };
    
    // Select destinations based on interests
    let selectedDestinations = [];
    interests.forEach(interest => {
        if (destinations[interest]) {
            selectedDestinations = selectedDestinations.concat(destinations[interest]);
        }
    });
    
    // Shuffle and limit based on days
    selectedDestinations = shuffleArray(selectedDestinations).slice(0, days * 2);
    
    // Create itinerary HTML
    let itineraryHTML = `
        <h3>Il tuo itinerario personalizzato</h3>
        <p>Partenza da: <strong>${startPoint}</strong> | Durata: <strong>${days} giorni</strong> | Interessi: <strong>${interests.join(', ')}</strong></p>
        <div class="itinerary-map">
            <img src="images/calabria-map.jpg" alt="Mappa della Calabria con itinerario" class="map-image">
        </div>
        <div class="itinerary-days">
    `;
    
    // Group destinations by day
    const destinationsPerDay = Math.ceil(selectedDestinations.length / days);
    
    for (let i = 0; i < days; i++) {
        const dayDestinations = selectedDestinations.slice(i * destinationsPerDay, (i + 1) * destinationsPerDay);
        
        itineraryHTML += `
            <div class="itinerary-day">
                <h4>Giorno ${i + 1}</h4>
                <div class="day-destinations">
        `;
        
        dayDestinations.forEach(dest => {
            itineraryHTML += `
                <div class="destination-card">
                    <div class="destination-image" style="background-image: url('${dest.image}')"></div>
                    <div class="destination-info">
                        <h5>${dest.name}</h5>
                        <p>${dest.description}</p>
                    </div>
                </div>
            `;
        });
        
        itineraryHTML += `
                </div>
            </div>
        `;
    }
    
    itineraryHTML += `
        </div>
        <div class="itinerary-actions">
            <button class="btn btn-primary">Salva itinerario</button>
            <button class="btn btn-secondary">Modifica itinerario</button>
            <button class="btn btn-secondary">Condividi</button>
        </div>
    `;
    
    // Display the itinerary
    demoResult.innerHTML = itineraryHTML;
    demoResult.style.display = 'block';
    
    // Scroll to the result
    window.scrollTo({
        top: demoResult.offsetTop - 80,
        behavior: 'smooth'
    });
    
    // Add event listeners to the new buttons
    const saveBtn = demoResult.querySelector('.btn-primary');
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            alert('Per salvare l\'itinerario, registrati gratuitamente!');
        });
    }
    
    const editBtn = demoResult.querySelector('.btn-secondary');
    if (editBtn) {
        editBtn.addEventListener('click', function() {
            alert('Per modificare l\'itinerario, registrati gratuitamente!');
        });
    }
    
    const shareBtn = demoResult.querySelectorAll('.btn-secondary')[1];
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            alert('Per condividere l\'itinerario, registrati gratuitamente!');
        });
    }
}

// Helper function to shuffle an array
function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}
