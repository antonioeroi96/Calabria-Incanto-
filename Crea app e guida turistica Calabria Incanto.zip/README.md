# README.md - Progetto Calabria Incanto

## Descrizione del Progetto

Calabria Incanto è un'applicazione web che genera itinerari turistici personalizzati in Calabria, permettendo agli utenti di scoprire le bellezze di questa regione in base alle proprie preferenze. Il progetto include una landing page interattiva, una guida turistica completa in PDF e la progettazione dettagliata di un'app web.

## Funzionalità Principali

- **Generazione di Itinerari Personalizzati**: Crea percorsi su misura in base a giorni disponibili, punto di partenza e tipologia preferita (mare, montagna, cultura, enogastronomia, avventura).
- **Guida Turistica PDF**: Una guida completa con informazioni dettagliate sulla Calabria, destinazioni top, consigli di viaggio e mappa interattiva.
- **Demo Interattiva**: Prova la funzionalità di generazione itinerari direttamente dalla landing page.
- **Design Responsive**: Esperienza ottimale su tutti i dispositivi, da desktop a mobile.

## Struttura del Repository

```
calabria-incanto/
├── docs/                           # Documentazione del progetto
├── guida_turistica/                # Guida turistica in PDF
├── landing-page/                   # Landing page del progetto
│   ├── css/                        # Fogli di stile CSS
│   ├── images/                     # Directory per le immagini
│   ├── js/                         # Script JavaScript
│   └── index.html                  # Landing page principale
└── README.md                       # Questo file
```

## Guida Rapida

### Visualizzazione della Landing Page

1. Clona il repository:
```bash
git clone https://github.com/tuousername/calabria-incanto.git
```

2. Apri il file `landing-page/index.html` nel tuo browser.

### Download della Guida Turistica

La guida turistica completa è disponibile in formato PDF nella directory `guida_turistica/`.

### Implementazione dell'App Web

Per implementare l'app web completa, consulta la documentazione dettagliata in `docs/architettura_app.md`.

## Tecnologie Utilizzate

- HTML5, CSS3, JavaScript
- Responsive Design
- Integrazione con Google Maps (progettata)
- Documentazione in Markdown

## Documentazione

Per informazioni dettagliate sul progetto, consulta i seguenti documenti:

- `docs/documentazione_completa.md`: Panoramica completa del progetto
- `docs/architettura_app.md`: Architettura dettagliata dell'app web
- `docs/design_landing_page.md`: Design della landing page
- `docs/pubblicazione_github_pages.md`: Istruzioni per la pubblicazione

## Requisiti Soddisfatti

- ✅ **Nessun costo iniziale**: Utilizzo esclusivo di strumenti gratuiti
- ✅ **Completamento in un'unica esecuzione**: Progetto sviluppato senza necessità di correzioni successive
- ✅ **Scalabilità**: Architettura progettata per essere facilmente espandibile
- ✅ **Documentazione chiara**: Guide dettagliate per l'aggiornamento di tutti i componenti

## Licenza

Tutti i contenuti originali di questo progetto sono rilasciati sotto licenza MIT. Le immagini utilizzate sono senza copyright da fonti come Pixabay, Unsplash o Pexels.

---

© 2025 Calabria Incanto. Tutti i diritti riservati.
