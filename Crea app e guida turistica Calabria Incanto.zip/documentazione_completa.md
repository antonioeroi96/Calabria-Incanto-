# Documentazione Progetto Calabria Incanto

## Panoramica del Progetto

Calabria Incanto è un'applicazione web che genera itinerari turistici personalizzati in Calabria. Il progetto include:

1. **Landing Page**: Una pagina web interattiva che presenta le funzionalità dell'app e permette agli utenti di provare una demo della generazione di itinerari.
2. **Guida Turistica PDF**: Una guida completa sulla Calabria con informazioni dettagliate sulle destinazioni, consigli di viaggio e itinerari consigliati.
3. **Architettura App Web**: La progettazione dettagliata dell'app web che potrebbe essere implementata con Bubble.io.
4. **Documentazione**: Istruzioni complete per l'aggiornamento e la manutenzione del progetto.

## Struttura del Repository

```
calabria-incanto/
├── docs/                           # Documentazione del progetto
│   ├── architettura_app.md         # Architettura dettagliata dell'app web
│   ├── design_landing_page.md      # Design della landing page
│   ├── pubblicazione_github_pages.md # Istruzioni per la pubblicazione
│   └── requisiti_progetto.md       # Requisiti originali del progetto
├── guida_turistica/                # Guida turistica in PDF
│   ├── 00_copertina_indice.md      # Copertina e indice della guida
│   ├── 01_introduzione.md          # Introduzione alla Calabria
│   ├── 02_destinazioni_top.md      # Destinazioni principali
│   ├── 03_consigli_viaggio.md      # Consigli di viaggio
│   ├── 04_mappa_interattiva.md     # Mappa interattiva
│   ├── Calabria_Incanto_Guida_Turistica.pdf # Guida completa in PDF
│   └── guida_completa.md           # Versione markdown della guida completa
├── landing-page/                   # Landing page del progetto
│   ├── css/                        # Fogli di stile CSS
│   │   ├── placeholders.css        # Stili per i placeholder delle immagini
│   │   └── styles.css              # Stili principali della landing page
│   ├── images/                     # Directory per le immagini (da popolare)
│   ├── js/                         # Script JavaScript
│   │   └── main.js                 # Funzionalità principali della landing page
│   ├── index.html                  # Versione principale della landing page
│   └── index-with-placeholders.html # Versione con placeholder per le immagini
└── README.md                       # Readme principale del progetto
```

## Tecnologie Utilizzate

- **HTML5**: Per la struttura della landing page
- **CSS3**: Per lo stile e il layout responsive
- **JavaScript**: Per l'interattività e la demo di generazione itinerari
- **Markdown**: Per la documentazione
- **Pandoc**: Per la conversione da Markdown a PDF
- **GitHub Pages**: Per l'hosting della landing page

## Funzionalità Implementate

### Landing Page

1. **Header con Navigazione**: Menu di navigazione responsive con link alle principali sezioni.
2. **Hero Section**: Presentazione principale con call-to-action per creare itinerari o scaricare la guida.
3. **Sezione Funzionalità**: Presentazione delle principali funzionalità dell'app.
4. **Demo Interattiva**: Form per generare un itinerario di esempio in base a preferenze dell'utente.
5. **Categorie di Itinerari**: Presentazione delle diverse tipologie di itinerari disponibili.
6. **Download Guida**: Sezione per scaricare la guida turistica PDF.
7. **Come Funziona**: Spiegazione del processo di creazione degli itinerari.
8. **FAQ**: Risposte alle domande frequenti.
9. **Footer**: Informazioni di contatto, link utili e form per la newsletter.

### Guida Turistica PDF

1. **Introduzione alla Calabria**: Storia, geografia, cultura e tradizioni.
2. **Destinazioni Top**: Descrizioni dettagliate delle principali località calabresi.
3. **Consigli di Viaggio**: Informazioni su trasporti, alloggi, gastronomia ed eventi.
4. **Mappa Interattiva**: Mappa con itinerari consigliati e distanze tra le principali località.

### Architettura App Web

1. **Struttura del Database**: Definizione delle tabelle e relazioni per utenti, destinazioni, itinerari e recensioni.
2. **Flussi di Lavoro**: Processi per registrazione, generazione itinerari, salvataggio e condivisione.
3. **Integrazione API**: Specifiche per l'integrazione con Google Maps, Google Login e Google Sheets.
4. **Interfaccia Utente**: Design dettagliato di tutte le schermate dell'app.
5. **Strategie di Crescita**: Piani per acquisizione utenti, retention e monetizzazione futura.

## Istruzioni per l'Aggiornamento

### Aggiornamento della Landing Page

1. **Sostituzione dei Placeholder**: Seguire le istruzioni in `docs/pubblicazione_github_pages.md` per sostituire i placeholder con immagini reali.
2. **Modifica dei Contenuti**: Aggiornare i testi e le descrizioni nel file `landing-page/index.html`.
3. **Aggiornamento degli Stili**: Modificare i file CSS in `landing-page/css/` per cambiare l'aspetto della landing page.
4. **Modifica delle Funzionalità**: Aggiornare il file `landing-page/js/main.js` per modificare le funzionalità interattive.

### Aggiornamento della Guida Turistica

1. **Modifica dei Contenuti**: Aggiornare i file markdown nella directory `guida_turistica/`.
2. **Rigenerazione del PDF**: Utilizzare Pandoc per convertire i file markdown aggiornati in un nuovo PDF.
3. **Aggiornamento del Link**: Assicurarsi che il link alla guida nella landing page punti al nuovo PDF.

### Implementazione dell'App Web con Bubble.io

1. **Creazione dell'Account**: Registrarsi su Bubble.io e creare un nuovo progetto.
2. **Implementazione del Database**: Seguire la struttura definita in `docs/architettura_app.md`.
3. **Creazione dell'Interfaccia**: Implementare le schermate come descritto nella documentazione.
4. **Configurazione dei Flussi di Lavoro**: Implementare i flussi di lavoro per le varie funzionalità.
5. **Integrazione API**: Configurare le integrazioni con Google Maps, Google Login e Google Sheets.
6. **Test e Pubblicazione**: Testare l'app e pubblicarla.

## Requisiti Tecnici

### Per la Landing Page

- Browser moderno con supporto per HTML5, CSS3 e JavaScript ES6
- Connessione internet per caricare font, icone e interagire con la demo

### Per l'Implementazione dell'App Web

- Account Bubble.io (versione gratuita)
- Account Google per l'integrazione con Google Maps, Google Login e Google Sheets
- Account Refersion (versione gratuita) per il sistema di affiliazione

## Contatti e Supporto

Per assistenza o domande sul progetto, contattare:
- Email: [inserire email di contatto]
- GitHub: [inserire link al repository GitHub]

## Licenza

Tutti i contenuti originali di questo progetto sono rilasciati sotto licenza [inserire tipo di licenza]. Le immagini utilizzate sono senza copyright da fonti come Pixabay, Unsplash o Pexels.

---

© 2025 Calabria Incanto. Tutti i diritti riservati.
